package PACKAGE_NAME;

public class DeliveredState {
}
