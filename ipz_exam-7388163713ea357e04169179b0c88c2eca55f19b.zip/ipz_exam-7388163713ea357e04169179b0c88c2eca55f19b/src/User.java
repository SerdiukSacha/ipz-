package PACKAGE_NAME;

public class User {
}
