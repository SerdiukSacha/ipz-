package PACKAGE_NAME;

public interface Subscriber {
}
